name = "Ghamaleeon, the Otherworldly Slime"
description = "Ghamaleeon, an otherworldly slime joins the constant! For better or for worse.\nHas 150 Sanity and 150 hunger\n*Is an alchemist\n*Has a trusty pickaxe\n*Has a body made of fluids\n*Brain and heart are the same"
author = "Ghamaleeon"
version = "1.4.3"

api_version = 10

dst_compatible = true

dont_starve_compatible = false
reign_of_giants_compatible = false
shipwrecked_compatible = false

all_clients_require_mod = true 

icon_atlas = "modicon.xml"
icon = "modicon.tex"

server_filter_tags = {
"character",
}
