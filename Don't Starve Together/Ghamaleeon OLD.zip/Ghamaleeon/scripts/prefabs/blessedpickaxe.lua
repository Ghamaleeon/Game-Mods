local assets= {

	Asset( "ANIM", "anim/blessedpickaxe.zip"),
	Asset( "ANIM", "anim/swap_blessedpickaxe.zip"),
	
	Asset( "ATLAS", "images/inventoryimages/blessedpickaxe.xml"),
	Asset( "IMAGE", "images/inventoryimages/blessedpickaxe.tex"),
}
local prefabs = {}

local function OnEquip(inst,owner)
	if owner:HasTag("ghamaleeon_builder") then
		owner.AnimState:OverrideSymbol("swap_object","swap_blessedpickaxe","swap_blessedpickaxe")
		owner.AnimState:Show("ARM_carry")
		owner.AnimState:Hide("ARM_normal")
	else
		inst:DoTaskInTime(0, function()
			if owner and owner.components and owner.components.inventory then
				owner.components.inventory:GiveItem(inst)
				if owner.components.talker then owner.components.talker:Say("The handle is blocky. I can't hold it!") end
			end
		end)
	end
end

local function OnUnequip(inst,owner)
	owner.AnimState:Hide("ARM_carry")
	owner.AnimState:Show("ARM_normal")
end

local function fn() 
	local inst = CreateEntity()
	
	inst.entity:AddTransform()
	inst.entity:AddAnimState()
	inst.entity:AddNetwork()
	inst.entity:AddSoundEmitter()
	
	MakeInventoryPhysics(inst)
	
	inst.AnimState:SetBank("blessedpickaxe")
	inst.AnimState:SetBuild("blessedpickaxe")
	inst.AnimState:PlayAnimation("idle")
	
	inst:AddTag("tool")
	inst:AddTag("weapon")

	MakeInventoryFloatable(inst, "small", 0.05, {1.2, 0.75, 1.2})
	
	inst.entity:SetPristine()
	
	if not TheWorld.ismastersim then return inst end

	inst:AddComponent("equippable")
	inst.components.equippable:SetOnEquip(OnEquip)
	inst.components.equippable:SetOnUnequip(OnUnequip)

	inst:AddComponent("inspectable")

	inst:AddComponent("inventoryitem")
	inst.components.inventoryitem.imagename = "blessedpickaxe"
	inst.components.inventoryitem.atlasname = "images/inventoryimages/blessedpickaxe.xml"

	inst:AddComponent("tool")
	inst.components.tool:SetAction(ACTIONS.MINE, TUNING.MULTITOOL_AXE_PICKAXE_EFFICIENCY)
	inst.components.tool:SetAction(ACTIONS.HAMMER, 0.33)

	inst:AddComponent("weapon")
	inst.components.weapon:SetDamage(TUNING.WATHGRITHR_SPEAR_DAMAGE)

	MakeHauntableLaunch(inst)

	return inst end

return Prefab("common/inventory/blessedpickaxe", fn, assets)