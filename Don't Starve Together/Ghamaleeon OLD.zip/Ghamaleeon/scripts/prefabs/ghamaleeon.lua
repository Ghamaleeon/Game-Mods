local MakePlayerCharacter = require "prefabs/player_common"

local assets = {
	Asset("SCRIPT", "scripts/prefabs/player_common.lua"),
}

local prefabs = {}

TUNING.GHAMALEEON_HUNGER = 150
TUNING.GHAMALEEON_SANITY = 200

TUNING.GAMEMODE_STARTING_ITEMS.DEFAULT.GHAMALEEON = {"blessedpickaxe"}
TUNING.STARTING_ITEM_IMAGE_OVERRIDE.blessedpickaxe = {
    atlas = "images/inventoryimages/blessedpickaxe.xml",
	image = "blessedpickaxe.tex"
}

local start_inv = {}
for k, v in pairs(TUNING.GAMEMODE_STARTING_ITEMS) do
	start_inv[string.lower(k)] = v.GHAMALEEON
end
local prefabs = FlattenTree(start_inv, true)

local function onbecamehuman(inst)
	inst.components.locomotor:SetExternalSpeedMultiplier(inst, "ghamaleeon_speed_mod", 1.025)
end

local function onbecameghost(inst)
	inst.components.locomotor:RemoveExternalSpeedMultiplier(inst, "ghamaleeon_speed_mod")
end

local function onload(inst)
	inst:ListenForEvent("ms_respawnedfromghost", onbecamehuman)
	inst:ListenForEvent("ms_becameghost", onbecameghost)

	if inst:HasTag("playerghost") then onbecameghost(inst)
	else onbecamehuman(inst) end
end

-- He likes watermelon, not cooked tho, cactus meat nerf.
local food_stat_dict = {
	watermelon = { health = 5, hunger = 25, sanity = 12.5 },
	watermelonicle = { health = 5, hunger = 25, sanity = 25 },
	cactus_meat_cooked = { health = 1, hunger = 12.5, sanity = 6 }
}

local function calculateFoodValues(player, food)
	local healthval, hungerval, sanityval = 0, 0, 0
	local edible_comp = food.components.edible
	local changesweremade = true
	
	local food_stats = food_stat_dict[food.prefab]
	
	healthval = 0
	if food_stats ~= nil then
		hungerval = food_stats["hunger"] + math.max(food_stats["health"] / 2, 0)
		sanityval = food_stats["sanity"] + math.min(food_stats["health"] / 2, 0)
	else
		hungerval = edible_comp.hungervalue + math.max(edible_comp.healthvalue / 2, 0)
		sanityval = edible_comp.sanityvalue + math.min(edible_comp.healthvalue / 2, 0)
	end
	
	return changesweremade, healthval, hungerval, sanityval
end

local function healthChanged(inst, data)
	if inst:HasTag("playerghost") then return end
	if inst.components.health and inst.components.sanity and inst.components.hunger then
		if data.amount < 0 then inst.components.sanity:DoDelta(data.amount) -- Every time his health changes negatively, his sanity will change as well.
		elseif data.amount > 0 then inst.components.hunger:DoDelta(data.amount / 2) end -- Every time his health changes positively, his hunger will change as well.
	end 
end

local function sanityChanged(inst, data)
	if inst:HasTag("playerghost") then return end
	if inst.components.health and inst.components.sanity then
		inst.components.sanity.penalty = inst.components.health.penalty -- Sanity penalty equals to health penalty.
		if inst.components.sanity.current > 1 then inst.components.health:SetCurrentHealth(inst.components.sanity.current) -- Every time sanity changes, health will change as well.
		elseif inst.components.health.currenthealth > 0.05 then inst.components.health:SetCurrentHealth(0.05) end -- This is to prevent a weird bug from happening.
		inst.components.health:ForceUpdateHUD() --For mods that show his health to other players.
	end
end

local common_postinit = function(inst) 
	inst:AddTag("ghamaleeon_builder") -- Can build items with this tag
	inst.MiniMapEntity:SetIcon( "ghamaleeon.tex" )
end

local master_postinit = function(inst)
	inst.starting_inventory = start_inv[TheNet:GetServerGameMode()] or start_inv.default
	
	inst.soundsname = "ghamaleeon"
	inst.components.talker.Say = function() end -- This will make the character mute.
	
	inst.components.health:SetMaxHealth(TUNING.GHAMALEEON_SANITY) -- Health has same sanity amount
	inst.components.hunger:SetMax(TUNING.GHAMALEEON_HUNGER)
	inst.components.sanity:SetMax(TUNING.GHAMALEEON_SANITY)
	
	inst.components.hunger.hungerrate = TUNING.WILSON_HUNGER_RATE
	
	inst.components.sanity.neg_aura_mult = TUNING.WENDY_SANITY_MULT -- Less sanity loss from auras
	inst.components.health.fire_damage_scale = TUNING.WILLOW_FIRE_DAMAGE -- No damage from fire
	inst.components.sanity.no_moisture_penalty = true -- No moisture sanity drain, neither item slipping
	
	inst.AnimState:SetScale(0.975, 0.975, 0.975) -- A little bit smaller than average character
	
	-- inst.components.builder:UnlockRecipe("healingsalve")
	
	-- Each event will call their respective function.
	inst:ListenForEvent("healthdelta", healthChanged)
	inst:ListenForEvent("sanitydelta", sanityChanged)
	
	-- Thanks to Ultroman who did this code!
	local old_Eat = inst.components.eater.Eat
	inst.components.eater.Eat =  function(self, food)
		local edible_comp = food.components.edible
		local changesweremade = false
		if edible_comp then
			local healthval, hungerval, sanityval
			-- Calculate the food values, and let us know if changes were made to them.
			changesweremade, healthval, hungerval, sanityval = calculateFoodValues(self.inst, food)
			if changesweremade then
				-- We first save the original food values, since we want to reset them after changing them temporarily for our character.
				edible_comp.originalhealthvalue = edible_comp.healthvalue
				edible_comp.originalhungervalue = edible_comp.hungervalue
				edible_comp.originalsanityvalue = edible_comp.sanityvalue
			
				-- We change the food to have our new stat values, and default to 0 if the stat was omitted from the dictionary entry.
				edible_comp.healthvalue = healthval
				edible_comp.hungervalue = hungerval
				edible_comp.sanityvalue = sanityval
			end
		end
		-- Call the original Eat function, while the food has our new values, and save the result in a variable.
		local returnvalue = old_Eat(self, food)
	
		-- If we made changes to the food, and the food is still valid (meaning it has not been destroyed
		-- because it was the last in the stack), and the edible component is still accessible...
		if food:IsValid() and changesweremade then
			-- We reset the food values after eating it.
			edible_comp.healthvalue = edible_comp.originalhealthvalue
			edible_comp.hungervalue = edible_comp.originalhungervalue
			edible_comp.sanityvalue = edible_comp.originalsanityvalue
			edible_comp.originalhealthvalue = nil
			edible_comp.originalhungervalue = nil
			edible_comp.originalsanityvalue = nil
		end
		return returnvalue
	end
	
	inst.OnLoad = onload
	inst.OnNewSpawn = onload
end

return MakePlayerCharacter("ghamaleeon", prefabs, assets, common_postinit, master_postinit, prefabs)
